
import React, { Component} from 'react';
import Title from './components/Title';
import Form from './components/Form';
import List from './components/List';
// import { filter, includes, orderBy as funcOrderBy, remove, reject } from 'lodash';
//App -> list -> item -> 
class App extends Component {
  state = {
    items: [
      {
        imgLink:"http://bit.ly/3ayPusa",
        altImg:"Image 1",
        withImg:"200",
        isClick: false
      },
      {
        imgLink:"http://bit.ly/3ayPusa",
        altImg:"Image 1",
        withImg:"200",
        isClick: false
      },
      {
        imgLink:"http://bit.ly/3ayPusa",
        altImg:"Image 1",
        withImg:"200",
        isClick: false
      },
      {
        imgLink:"http://bit.ly/3ayPusa",
        altImg:"Image 1",
        withImg:"200",
        isClick: false
      },
      {
        imgLink:"http://bit.ly/3ayPusa",
        altImg:"Image 1",
        withImg:"200",
        isClick: false
      },
      {
        imgLink:"http://bit.ly/3ayPusa",
        altImg:"Image 1",
        withImg:"200",
        isClick: false
      },
      {
        imgLink:"http://bit.ly/3ayPusa",
        altImg:"Image 1",
        withImg:"200",
        isClick: false
      },
      {
        imgLink:"http://bit.ly/3ayPusa",
        altImg:"Image 1",
        withImg:"200",
        isClick: false
      },
      {
        imgLink:"http://bit.ly/3ayPusa",
        altImg:"Image 1",
        withImg:"200",
        isClick: false
      },
    ],
    isShowForm: false,
    strSearch: '',
    orderBy: 'name',
    orderDir: 'asc',
    itemSelected: null
 }

  constructor(props) {
    super(props)
    this.handleToggleForm = this.handleToggleForm.bind(this);
  }
  handleToggleForm = () =>{
    this.setState({
      isClick: !this.state.isClick
    });
  }


  render(){
    let itemsOrigin =(this.state.items !== null)? [...this.state.items]: [];
    console.log(itemsOrigin);
    
    let items = [];
    
    // console.log(orderBy + "-" + orderDir);
    return(
      <div>
        <Title/>
        <List 
          onClickImg = {this.handleToggleForm}
          
          items = {items}/>
        
      </div>
    ) 
}
}

export default App;
