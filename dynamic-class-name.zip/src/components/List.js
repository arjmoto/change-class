import React, { Component} from 'react';
import Item from './Item';
class List extends Component {
  constructor(props) {
    super(props);
    this.state = {

    };
    // console.log(this.props.items);
    // progs.onClickEdit = App.handleEdit
  }

    render(){
        const items = this.props.items;
        console.log(items);
        const elmItem = items.map((item, index) =>{
          return (
            <Item 
            onClickEdit = {this.props.onClickEdit}
            key = {index} 
            item = {item} 
            index = {index}/>
          );
        })
        return(
        <div className="panel panel-success">
          <div className="panel-heading">List Item</div>
          <table className="table table-hover ">
            <thead>
              <tr>
                <th style={{width: '33%'}} className="text-center">Image column 1</th>
                <th style={{width: '33%'}} className="text-center">Image column 2</th>
                <th style={{width: '33%'}} className="text-center">Image column 3</th>
              </tr>
            </thead>
            <tbody>
              {elmItem}
              
            </tbody>
          </table>
        </div>
      
        ) 
    }
}

export default List;