import React, { Component} from 'react';
import Lesson from './Lesson';

class Course extends Component {
    constructor(props){
        super(props);
        this.state = {
            isShowOutline: false,
            totalStudent: 69
        };
        this.handleClick3 = this.handleClick3.bind(this);
        this.registerCourse = this.registerCourse.bind(this);
        this.handleToogleOutline = this.handleToogleOutline.bind(this);
    }
    handleClick1(){
        alert("view 1");
    }
    handleClick2(content){
        alert(content);
    }
    handleClick3(){
        alert(this.props.name);
    }
    registerCourse(){
        alert("register");
        // console.log(this.props);
        // console.log(this.refs.username.value);
    }
    showButtonFree(){
        const isFree = this.props.free;
        console.log("isFree", isFree);
        if(isFree === true){
         return   (
            <div className="btn-group">
            <button onClick={this.handleClick1} type="button" className="btn btn-warning">View 1</button>        
            <button onClick={() => this.handleClick2("view 232")} type="button" className="btn btn-danger">View 2</button>        
            <button onClick={this.handleClick3} type="button" className="btn btn-success">View 3</button>        
        </div>
         )                        
        }else{
            return(
                <div className="input-group mb-3">
                    <div className="input-group-prepend">
                    <button onClick={this.registerCourse} className="btn btn-info" type="button" id="button-addon1">Register</button>
                    </div>
                    <input type="text" className="form-control" placeholder="Username"  />
                </div>
            )
        }
    }
    handleToogleOutline() {
        this.setState({
            isShowOutline: !this.state.isShowOutline
        })
    }
    render(){
        console.log(this.state);
        console.log(this.render)
        let elmOutline = null;
        if(this.state.isShowOutline){
            elmOutline = <ul className="list-group list-group-flush">
                <Lesson/>
                <Lesson/>
                <Lesson/>
            </ul>;
        }
        return(
                <div className="col-xs-4 col-sm-4 col-md-4 col-lg-4">
                <div className="card">
                    <div className="card-header">
                        {this.props.name}
                    </div>
                    <div className="card-body">
                        <p>{this.props.time}</p>
                        <p>{this.props.children}</p>
                        <p><button onClick = {this.handleToogleOutline} type="button" className="btn btn-success">
                            Toogle Outline</button></p>
                        {elmOutline}
                    </div>
                    <div className="card-footer">
                        {this.showButtonFree()}
                    </div>
                   
                </div>
                </div>
                // <button type="button" className="btn btn-success"></button>
        ) 
    }
}

export default Course;