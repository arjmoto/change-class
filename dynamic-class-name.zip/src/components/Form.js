import React, { Component} from 'react';

class Form extends Component {
    constructor(props) {
        super(props);
        this.state = {
            item_id: '',
            item_name: '',
            item_level: 0
        };
        // console.log(this.props.items);
        this.handlCancel = this.handlCancel.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        // this.updateItem = this.updateItem.bind(this);
        // console.log(this.props.itemSelected)
      }
    componentWillMount(){
        this.updateItem(this.props.itemSelected);
    }
    componentWillReceiveProps(nextProps){
        this.updateItem(nextProps.itemSelected);
    }
    updateItem(item){
        if(item !== null){
            this.setState({
                item_id: item.id,
                item_name: item.name,
                item_level: item.level   
            })
        }
        // this.handlCancel();
   }
    handlCancel(){
        // console.log("handlCancle"+ this.props);
        this.props.onClickCancel();
    }
    handleChange(event) {
        // this.setState({value: event.target.value});
        const target = event.target;
        const value =  target.type === 'checkbox' ? target.checked : target.value;
        const name = target.name;
    
        this.setState({
          [name]: value
        });
        // console.log(this.state)
      }
    
      handleSubmit(event) {
        // alert('An essay was submitted: ' + this.state.firstName);
        console.log(this.state)
        let item = {
            id: this.state.item_id,
            name: this.state.item_name,
            level: this.state.item_level
        }
        this.props.onClickSubmit(item);
        event.preventDefault();
      }
    render(){
       
        return(
        <div className="row marginB10">
            <div className="col-md-offset-7 col-md-5">
                <form className="form-inline" onSubmit={this.handleSubmit}>
                <div className="form-group">
                    <input value={this.state.item_name} onChange={this.handleChange} name="item_name" type="text" className="form-control" placeholder="Item Name" />
                </div>
                <div className="form-group">
                    <select value={this.state.item_level} onChange={this.handleChange}  name = "item_level" className="form-control">
                    <option value={0}>Small</option>
                    <option value={1}>Medium</option>
                    <option value={2}>High</option>
                    </select>
                </div>
                <button type="submit" className="btn btn-primary">Submit</button>
                <button onClick={this.handlCancel} type="button" className="btn btn-default">Cancel</button>
                </form>
            </div>
        </div>
        ) 
    }
}

export default Form;