import React, { Component} from 'react';

class Item extends Component {
  constructor(props) {
    super(props);
    this.state = {};
    this.handleClick = this.handleClick.bind(this);
  }
 
  handleClick(){
    // console.log("handleAdd");
    this.props.onClickImg();
  }
  
    render(){
      let className = 'Img';
      if(this.props.isClick){
        className = 'ImgChange'
      }
      const {item} = this.props;
      const {index} = this.props;
      console.log(item);
      
        return(
            <tr>
                <td className="text-center">
                  <img onClick={this.handleClick} src="http://bit.ly/3ayPusa" alt={index} width={item.withImg} style={{width: '100px'}} />
                </td>
                <td> <td>
                  <img className = {className} onClick={this.handleClick} src={item.imgLink} alt={item.altImg} width={item.withImg}  />
                </td></td>
                <td className="text-center"> <td>
                  <img className = {className} onClick={this.handleClick} src={item.imgLink} alt={item.altImg} width={item.withImg}  />
                </td></td>
            </tr>
        ) 
    }
   
}

export default Item;