import React, { Component} from 'react';

class Title extends Component {
    render(){
        return(
            <div className="page-header">
                <h1>Project 01 - ToDo List <small>Learn ReactJS</small></h1>
            </div>
        ) 
    }
}

export default Title;